var tabelkontak = null,
    tabelperson = null,
    tabeltransaksi = null;

$(function() {
  
  $.fn.dataTable.ext.errMode = 'none';
  

  if(!parent.window.$(".loader-wrap").hasClass("d-none")){
    parent.window.$(".loader-wrap").addClass("d-none");
  }

});