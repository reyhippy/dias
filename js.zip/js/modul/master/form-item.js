/* Form Init */
$('.numeric').inputmask({
  alias:'numeric',
  digits:'2',
  digitsOptional:false,
  isNumeric: true,      
  prefix:'',
  groupSeparator:".",
  placeholder: '0',
  radixPoint:",",
  autoGroup:true,
  autoUnmask:true,
  onBeforeMask: function (value, opts) {
    //console.dir(opts);
    return value;
  },
  removeMaskOnSubmit:false
});

$('#jenis').select2({
     "theme":"bootstrap4",
     "dropdownParent": $('#tabItem'),
     "minimumResultsForSearch": "Infinity"                                         
}); 

$('#tipe').select2({
     "theme":"bootstrap4",
     "dropdownParent": $('#tabItem'),
     "minimumResultsForSearch": "Infinity"                                     
}); 

$('#status').select2({
     "theme":"bootstrap4",
     "dropdownParent": $('#tabItem'),
     "minimumResultsForSearch": "Infinity"                    
}); 

$('#satuanD').select2({
     "allowClear": true,
     "theme":"bootstrap4",
     "dropdownParent": $('#tabItem'),          
     "ajax": {
        "url": base_url+"Select_Master/view_satuan",
        "type": "post",
        "dataType": "json",                                       
        "delay": 800,
        "data": function(params) {
          return {
            search: params.term
          }
        },
        "processResults": function (data, page) {
        return {
          results: data
        };
      },
    }
});

$('#satuanDef').select2({
     "allowClear": true,
     "theme":"bootstrap4",
     "dropdownParent": $('#tabItem'),          
     "ajax": {
        "url": base_url+"Select_Master/view_satuan",
        "type": "post",
        "dataType": "json",                                       
        "delay": 800,
        "data": function(params) {
          return {
            search: params.term
          }
        },
        "processResults": function (data, page) {
        return {
          results: data
        };
      },
    }
});

$('#kategori').select2({
     "allowClear": true,
     "theme":"bootstrap4",
     "ajax": {
        "url": base_url+"Select_Master/view_kategori_item",
        "type": "post",
        "dataType": "json",                                       
        "delay": 800,
        "data": function(params) {
          return {
            search: params.term
          }
        },
        "processResults": function (data, page) {
        return {
          results: data
        };
      },
    }
});

$('#subkategori').select2({
     "allowClear": true,
     "theme":"bootstrap4",
     "ajax": {
        "url": base_url+"Select_Master/view_subkategori_item",
        "type": "post",
        "dataType": "json",                                       
        "delay": 800,
        "data": function(params) {
          return {
            search: params.term
          }
        },
        "processResults": function (data, page) {
        return {
          results: data
        };
      },
    }
});

$('#coapersediaan,#coapendapatan,#coahpp').select2({
     "allowClear": true,
     "theme":"bootstrap4",
     "dropdownParent": $('#tabItem'),          
     "ajax": {
        "url": base_url+"Select_Master/view_coa",
        "type": "post",
        "dataType": "json",                                       
        "delay": 800,
        "data": function(params) {
          return {
            search: params.term
          }
        },
        "processResults": function (data, page) {
        return {
          results: data
        };
      },
    },
     "templateResult": textSelect,              
});  

function textSelect(par){
  if(!par.id){
    return par.text;
  }
  var $par = $('<span>('+par.kode+') '+par.text+'</span>');
  return $par;
}

function _clearForm(){
  $(":input").not(":button, :submit, :reset, :checkbox, :radio").val('');
  $(":checkbox").prop("checked", false);       
  $('.select2').val('').change();                  
}       

get_default_coa('ITP');
get_default_coa('ITT');
get_default_coa('ITH');

function get_default_coa(id){
    $.ajax({ 
      "url"    : base_url+"Master_Item/getdefaultcoa",       
      "type"   : "POST", 
      "dataType" : "json", 
      "data" : "id="+id,
      "cache"  : false,
      "error"  : function(xhr,status,error){
        $(".main-modal-body").html('');        
        toastr.error("Perbaiki kesalahan ini : "+xhr.status+" "+error);
        console.error(xhr.responseText);
        return;
      },
      "success" : function(result) {
        if (typeof result.pesan !== 'undefined') { // Jika ada pesan maka tampilkan pesan
          toastr.error(result.pesan);
          return;
        } else { // Jika tidak ada pesan tampilkan json ke form
          const _coa = $("<option selected='selected'></option>").val(result.data[0]['idcoa']).text(result.data[0]['coa']);

          if(result.data[0]['coa']!==null){
            if(id=='ITP') {
              $('#coapersediaan').append(_coa);                      
            }            
            if(id=='ITT') {
              $('#coapendapatan').append(_coa);                      
            }                        
            if(id=='ITH') {
              $('#coahpp').append(_coa);                      
            }                                    
          }

          /**/
          return;
        }
    } 
  })  
}

$(document).on('select2:open', () => {
  document.querySelector('.select2-search__field').focus();
});     

$(this).on('shown.bs.tooltip', function (e) {
  setTimeout(function () {
    $(e.target).tooltip('hide');
  }, 2000);
});
/* End Form Init */

$("#submit").click(function(){
  if (_IsValid()===0) return;
  _saveData();
});

var _IsValid = (function(){
    //Cek Header Input
    if ($('#nomor').val()==''){
      $('#nomor').attr('data-title','Kode barang/jasa harus diisi !');      
      $('#nomor').tooltip('show');
      $('#nomor').focus();
      return 0;
    }

    if ($('#nama').val()==''){
      $('#nama').attr('data-title','Nama barang/jasa harus diisi !');      
      $('#nama').tooltip('show');
      $('#nama').focus();
      return 0;
    }

    if ($('#satuanD').val()=='' || $('#satuanD').val()==null){
      $('#satuanD').attr('data-title','Satuan dasar harus diisi !');      
      $('#satuanD').tooltip('show');
      $('#satuanD').focus();
      return 0;
    }    

    if ($('#satuanDef').val()=='' || $('#satuanDef').val()==null){
      $('#satuanDef').attr('data-title','Satuan default harus diisi !');      
      $('#satuanDef').tooltip('show');
      $('#satuanDef').focus();
      return 0;
    }        

    return 1;
});

var _saveData = (function(){
  const id = $("#id").val(),
        kode = $("#nomor").val(),
        nama = $("#nama").val(),
        satuan = $("#satuanD").val(),
        satuand = $("#satuanDef").val(),
        jenis = $("#jenis").val(),
        tipe = $("#tipe").val(),    
        stokmin = Number($("#stokmin").val().split('.').join('').toString().replace(',','.')),
        stokmaks = Number($("#stokmaks").val().split('.').join('').toString().replace(',','.')),                
        stokreorder = Number($("#stokreorder").val().split('.').join('').toString().replace(',','.')),
        hargabeli = Number($("#hargabeli").val().split('.').join('').toString().replace(',','.')),
        hargajual1 = Number($("#hargajual1").val().split('.').join('').toString().replace(',','.')),
        hargajual2 = Number($("#hargajual2").val().split('.').join('').toString().replace(',','.')),
        hargajual3 = Number($("#hargajual3").val().split('.').join('').toString().replace(',','.')),
        hargajual4 = Number($("#hargajual4").val().split('.').join('').toString().replace(',','.')), 
        coapersediaan = $("#coapersediaan").val(),
        coapendapatan = $("#coapendapatan").val(),                                                   
        coahpp = $("#coahpp").val(),
        status = $("#status").val();

  var rey = new FormData();  
  rey.set('id',id);
  rey.set('kode',kode);
  rey.set('nama',nama);
  rey.set('satuan',satuan);
  rey.set('satuand',satuand);
  rey.set('jenis',jenis);
  rey.set('tipe',tipe);
  rey.set('stokmin',stokmin);
  rey.set('stokmaks',stokmaks);    
  rey.set('stokreorder',stokreorder);
  rey.set('hargabeli',hargabeli);
  rey.set('hargajual1',hargajual1);
  rey.set('hargajual2',hargajual2);
  rey.set('hargajual3',hargajual3);
  rey.set('hargajual4',hargajual4);      
  rey.set('coapersediaan',coapersediaan);        
  rey.set('coapendapatan',coapendapatan);          
  rey.set('coahpp',coahpp);            
  rey.set('status',status);  

  $.ajax({ 
    "url"    : base_url+"Master_Item/savedata", 
    "type"   : "POST", 
    "data"   : rey,
    "processData": false,
    "contentType": false,
    "cache"    : false,
    "beforeSend" : function(){
      $(".loader-wrap").removeClass("d-none");
    },
    "error": function(xhr, status, error){
      $(".loader-wrap").addClass("d-none");
      toastr.error("Perbaiki masalah ini : "+xhr.status+" "+error);      
      console.log(xhr.responseText);      
      return;
    },
    "success": function(result) {
      $(".loader-wrap").addClass("d-none");        

      if(result=='sukses'){
        $('#modal').modal('hide');                
        toastr.success("Data item berhasil disimpan");                  
        return;
      } else {        
        toastr.error(result);                          
        return;
      }
    } 
  });
});

function _getData(id){
    if(id=='' || id==null) return;    

    $.ajax({ 
      "url"    : base_url+"Master_Item/getdata",       
      "type"   : "POST", 
      "dataType" : "json", 
      "data" : "id="+id,
      "cache"  : false,
      "beforeSend" : function(){
        $('.loader-wrap').removeClass('d-none');        
      },        
      "error"  : function(xhr,status,error){
        $(".main-modal-body").html('');        
        toastr.error("Perbaiki kesalahan ini : "+xhr.status+" "+error);
        console.error(xhr.responseText);
        $('.loader-wrap').addClass('d-none');                  
        return;
      },
      "success" : function(result) {
        if (typeof result.pesan !== 'undefined') { // Jika ada pesan maka tampilkan pesan
          toastr.error(result.pesan);
          $('.loader-wrap').addClass('d-none'); 
          return;
        } else { // Jika tidak ada pesan tampilkan json ke form
          const _satuan = $("<option selected='selected'></option>").val(result.data[0]['idsatuan']).text(result.data[0]['satuan']),
                _satuanD = $("<option selected='selected'></option>").val(result.data[0]['idsatuand']).text(result.data[0]['satuand']),
                _coapersediaan = $("<option selected='selected'></option>").val(result.data[0]['idcoapersediaan']).text(result.data[0]['coapersediaan']),
                _coapendapatan = $("<option selected='selected'></option>").val(result.data[0]['idcoapendapatan']).text(result.data[0]['coapendapatan']),
                _coahpp = $("<option selected='selected'></option>").val(result.data[0]['idcoahpp']).text(result.data[0]['coahpp']);

          $('#id').val(result.data[0]['id']);            
          $('#nomor').val(result.data[0]['kode']);
          $('#nama').val(result.data[0]['nama']);          
          if(result.data[0]['satuan']!==null) $('#satuanD').append(_satuan);          
          if(result.data[0]['satuand']!==null) $('#satuanDef').append(_satuanD); 
          $('#stokmin').val(result.data[0]['stokmin'].replace(".", ","));                                                     
          if(result.data[0]['stokmin']==0) $("#stokmin").attr('placeholder','0,00');            
          $('#stokmaks').val(result.data[0]['stokmaks'].replace(".", ","));                                                     
          if(result.data[0]['stokmaks']==0) $("#stokmaks").attr('placeholder','0,00');                      
          $('#stoktotal').val(result.data[0]['stoktotal'].replace(".", ","));                                                     
          if(result.data[0]['stoktotal']==0) $("#stoktotal").attr('placeholder','0,00');                                
          $('#stokreorder').val(result.data[0]['reorder'].replace(".", ","));                                                     
          if(result.data[0]['reorder']==0) $("#stokreorder").attr('placeholder','0,00');                                
          $('#hargabeli').val(result.data[0]['hargabeli'].replace(".", ","));                                                     
          if(result.data[0]['hargabeli']==0) $("#hargabeli").attr('placeholder','0,00');
          $('#hargajual1').val(result.data[0]['hargajual1'].replace(".", ","));                                                     
          if(result.data[0]['hargajual1']==0) $("#hargajual1").attr('placeholder','0,00');
          $('#hargajual2').val(result.data[0]['hargajual2'].replace(".", ","));                                                     
          if(result.data[0]['hargajual2']==0) $("#hargajual2").attr('placeholder','0,00');
          $('#hargajual3').val(result.data[0]['hargajual3'].replace(".", ","));                                                     
          if(result.data[0]['hargajual3']==0) $("#hargajual3").attr('placeholder','0,00');
          $('#hargajual4').val(result.data[0]['hargajual4'].replace(".", ","));                                                     
          if(result.data[0]['hargajual4']==0) $("#hargajual4").attr('placeholder','0,00');                                        
          $('#jenis').val(result.data[0]['jenis']).trigger('change');
          $('#tipe').val(result.data[0]['tipe']).trigger('change');          
          $('#status').val(result.data[0]['status']).trigger('change');                    

          if(result.data[0]['coapersediaan']!==null) $('#coapersediaan').append(_coapersediaan);          
          if(result.data[0]['coapendapatan']!==null) $('#coapendapatan').append(_coapendapatan);                    
          if(result.data[0]['coahpp']!==null) $('#coahpp').append(_coahpp);                    
          /**/
          $('.loader-wrap').addClass('d-none');                                       
          return;
        }
    } 
  })
}

setTimeout(function (){
        $('#nomor').focus();
    }, 500);                   