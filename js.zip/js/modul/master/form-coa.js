/* Form Init */

setTimeout(function (){
        $('#tipe').focus();
    }, 500);           

$('#tipe').select2({
     "allowClear": true,
     "theme":"bootstrap4",
     "dropdownParent": $('#tabCOA'),     
     "ajax": {
        "url": base_url+"Select_Master/view_coa_tipe",
        "type": "post",
        "dataType": "json",                                       
        "delay": 800,
        "data": function(params) {
          return {
            search: params.term
          }
        },
        "processResults": function (data, page) {
        return {
          results: data
        };
      },
    }
});

$('#uang').select2({
     "allowClear": true,
     "theme":"bootstrap4",
     "dropdownParent": $('#tabCOA'),     
     "ajax": {
        "url": base_url+"Select_Master/view_mata_uang",
        "type": "post",
        "dataType": "json",                                       
        "delay": 800,
        "data": function(params) {
          return {
            search: params.term
          }
        },
        "processResults": function (data, page) {
        return {
          results: data
        };
      },
    }
}); 

$('#divisi').select2({
     "allowClear": true,
     "theme":"bootstrap4",
     "dropdownParent": $('#tabCOA'),     
     "ajax": {
        "url": base_url+"Select_Master/view_divisi",
        "type": "post",
        "dataType": "json",                                       
        "delay": 800,
        "data": function(params) {
          return {
            search: params.term
          }
        },
        "processResults": function (data, page) {
        return {
          results: data
        };
      },
    }
});

$('#bank').select2({
     "allowClear": true,
     "theme":"bootstrap4",
     "dropdownParent": $('#tabCOA'),     
     "ajax": {
        "url": base_url+"Select_Master/view_bank",
        "type": "post",
        "dataType": "json",                                       
        "delay": 800,
        "data": function(params) {
          return {
            search: params.term
          }
        },
        "processResults": function (data, page) {
        return {
          results: data
        };
      },
    }
});

$('#indukakun').select2({
     "allowClear": true,
     "theme":"bootstrap4",
     "dropdownParent": $('#tabCOA'),     
     "ajax": {
        "url": base_url+"Select_Master/view_coa_induk",
        "type": "post",
        "dataType": "json",                                       
        "delay": 800,
        "data": function(params) {
          return {
            search: params.term
          }
        },
        "processResults": function (data, page) {
        return {
          results: data
        };
        },        
    },
     "templateResult": textSelect,    
}); 

$('#gd').select2({
     "minimumResultsForSearch": "Infinity",                 
     "theme":"bootstrap4"
});

$('#chksub').click(function(){
  if ($('#chksub').is(":checked"))
  {
    $('#indukakun').removeAttr('disabled');
    $('#indukakun').focus();
  } else {
    $('#indukakun').attr('disabled','disabled');
    $('#indukakun').val(null).trigger('change');    
  }
});      

function textSelect(par){
  if(!par.id){
    return par.text;
  }
  var $par = $('<span>('+par.kode+') '+par.text+'</span>');
  return $par;
}

$(document).on('select2:open', () => {
  document.querySelector('.select2-search__field').focus();
});

$(this).on('shown.bs.tooltip', function (e) {
  setTimeout(function () {
    $(e.target).tooltip('hide');
  }, 2000);
});
/* End Form Init */

$("#submit").click(function(){
  if (_IsValid()===0) return;
  _saveData();
});

var _IsValid = (function(){
    if ($('#tipe').val()=='' || $('#tipe').val()==null){
      $('#tipe').attr('data-title','Tipe Akun harus diisi !');      
      $('#tipe').tooltip('show');
      $('#tipe').focus();
      return 0;
    }    
    if ($('#nomor').val()==''){
      $('#nomor').attr('data-title','Nomor akun harus diisi !');      
      $('#nomor').tooltip('show');
      $('#nomor').focus();
      return 0;
    }
    if ($('#nama').val()==''){
      $('#nama').attr('data-title','Nomor akun harus diisi !');      
      $('#nama').tooltip('show');
      $('#nama').focus();
      return 0;
    }
    return 1;
});

var _saveData = (function(){
  const id = $("#id").val(),
        tipe = $("#tipe").val(),
        nomor = $("#nomor").val(),
        nama = $("#nama").val(),
        gd = $("#gd").val(),
        subcoa = $("#indukakun").val(),
        uang = $("#uang").val(),
        bank = $("#bank").val()!==null ? $("#bank").val() : undefined;
        nomorbank = $("#nomorbank").val(),
        divisi = $("#divisi").val()!==null ? $("#divisi").val() : undefined;

  var status = 1;

  if($("#aktif").prop('checked')==false) status=0;  

  var rey = new FormData();  
  rey.set('id',id);
  rey.set('tipe',tipe);
  rey.set('nomor',nomor);
  rey.set('nama',nama);
  rey.set('gd',gd);
  rey.set('subcoa',subcoa);
  rey.set('uang',uang);
  rey.set('bank',bank);
  rey.set('divisi',divisi);  
  rey.set('nomorbank',nomorbank);  
  rey.set('status',status);        

  $.ajax({ 
    "url"    : base_url+"Master_Akun/savedata", 
    "type"   : "POST", 
    "data"   : rey,
    "processData": false,
    "contentType": false,
    "cache"    : false,
    "beforeSend" : function(){
      $(".loader-wrap").removeClass("d-none");
    },
    "error": function(xhr, status, error){
      $(".loader-wrap").addClass("d-none");
      toastr.error("Perbaiki masalah ini : "+xhr.status+" "+error);      
      console.log(xhr.responseText);      
      return;
    },
    "success": function(result) {
      $(".loader-wrap").addClass("d-none");        

      if(result=='sukses'){
        $('#modal').modal('hide');                
        toastr.success("Data akun berhasil disimpan");                  
        return;
      } else {        
        toastr.error(result);                          
        return;
      }
    } 
  });
});

function _getData(id){
    if(id=='' || id==null) return;    

    $.ajax({ 
      "url"    : base_url+"Master_Akun/getdata",       
      "type"   : "POST", 
      "dataType" : "json", 
      "data" : "id="+id,
      "cache"  : false,
      "beforeSend" : function(){
        $('.loader-wrap').removeClass('d-none');        
      },        
      "error"  : function(xhr,status,error){
        $(".main-modal-body").html('');        
        toastr.error("Perbaiki kesalahan ini : "+xhr.status+" "+error);
        console.error(xhr.responseText);
        $('.loader-wrap').addClass('d-none');                  
        return;
      },
      "success" : function(result) {
        if (typeof result.pesan !== 'undefined') { // Jika ada pesan maka tampilkan pesan
          toastr.error(result.pesan);
          $('.loader-wrap').addClass('d-none'); 
          return;
        } else { // Jika tidak ada pesan tampilkan json ke form
          const _tipe = $("<option selected='selected'></option>").val(result.data[0]['idtipe']).text(result.data[0]['tipe']),
                _indukcoa = $("<option selected='selected'></option>").val(result.data[0]['idparent']).text(result.data[0]['parent']),
                _gd = $("<option selected='selected'></option>").val(result.data[0]['gd']).text(result.data[0]['gd']),
                _uang = $("<option selected='selected'></option>").val(result.data[0]['iduang']).text(result.data[0]['uang']),
                _divisi = $("<option selected='selected'></option>").val(result.data[0]['iddivisi']).text(result.data[0]['divisi']),
                _bank = $("<option selected='selected'></option>").val(result.data[0]['idbank']).text(result.data[0]['bank']);

          $('#id').val(result.data[0]['id']);            
          $('#nomor').val(result.data[0]['nomor']);
          $('#tipe').append(_tipe);
          if(result.data[0]['parent']!==null) $('#indukakun').append(_indukcoa);          
          $('#nama').val(result.data[0]['nama']);
          $('#gd').val(result.data[0]['gd']).trigger('change');     
          $('#uang').append(_uang);
          if(result.data[0]['divisi']!==null) $('#divisi').append(_divisi);               
          if(result.data[0]['bank']!==null) $('#bank').append(_bank);                         
          $('#nomorbank').val(result.data[0]['nobank']);          

          if(result.data[0]['sub']=='1'){
            $("#chksub").prop('checked',true);
            $('#indukakun').removeAttr('disabled');
          }

          if(result.data[0]['status']=='1'){
            $("#aktif").prop('checked',true);            
          }          
          /**/
          $('.loader-wrap').addClass('d-none');                                       
          return;
        }
    } 
  })
}