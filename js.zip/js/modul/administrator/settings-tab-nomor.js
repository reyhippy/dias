var tabelnomor = null;

$(function() {

	$("#btn-tab-nomor").click(function() {

	$("#badd").removeClass("disabled");
	$("#bedit").removeClass("disabled");	
	$("#bdelete").removeClass("disabled");
	$("#bsave").addClass("disabled");

  	if(!tabelnomor){
		tabelnomor=$('#nomor-table').DataTable({
		"processing": true,
		"serverSide": true,
		"lengthChange": false,
		"searching": false,
		"ordering": true,
		"pagingType":"simple",    
		"order": [[0, 'asc' ]],
		"select":true,  
		"dom": '<"top"pi>tr<"clear">',
		"ajax": {
		    "url":base_url+"Datatable_Transaksi_Full/view_penomoran",
		    "type":"post"
		},
		"deferRender": true,
		"bInfo":true,    
	    "aLengthMenu": datapage,
		"columns": [
		      { "data": "id" },
	          {
	          orderable:      false,
	          data:           null,
	          defaultContent: "<i class='fas fa-caret-right text-sm'></i>"
	          },    
		      { "data": "kode" },
		      { "data": "keterangan" },
		      { "data": "tabel" },
		      { "data": "tanggal" },
		      { "data": "sumber" },
		      { "data": "nomor" },
		      { "data": "kontak" },
		      { "data": "uraian" },
		      { "data": "total" },		      		      		      		      		      		      
		      { "data": "nid" },		      
	          { "orderable": true,
	            "render": function ( data, type, row ) {
	            	if(row.fa=='1'){
		                var html ="<input type='checkbox' name='rw[]' class='chkfa mt-1' checked>";
	            	}else{
		                var html ="<input type='checkbox' name='rw[]' class='chkfa mt-1'>";
	            	}
	                return html;
	                }
	          },
		],
	    "drawCallback": function() {
			var total = tabelnomor.data().count();

			if(total>0){
				$(".tab-wrap").removeClass("noresultfound-x");                                   
			}else{
				$(".tab-wrap").addClass("noresultfound-x"); 
			}  		
			if($(".table-utils-post").hasClass("d-none")){	  
			  	$(".table-utils-post").removeClass("d-none");
			}
		}                    
		});
  	} else {
		var total = tabelnomor.data().count();

		if(total>0){
			$(".tab-wrap").removeClass("noresultfound-x");                                   
		}else{
			$(".tab-wrap").addClass("noresultfound-x"); 
		}  		
  	}

	new $.fn.dataTable.ColResize(tabelnomor, {
	  isEnabled: true,
	  hoverClass: 'dt-colresizable-hover',
	  hasBoundCheck: true,
	  minBoundClass: 'dt-colresizable-bound-min',
	  maxBoundClass: 'dt-colresizable-bound-max',
	  isResizable: function(column) { 
	    return column.idx !== 1; 
	  },
	  onResize: function(column) {
	  },
	  onResizeEnd: function(column, columns) {
	  }
	});

  	});


	$("#bfilter-nomor").click(function() {
	  if($("#fDataTable-Nomor").hasClass("d-none")){
	    $("#nomor-table").removeClass("w-100");
	    $("#nomor-table").addClass("w-75");
	    $("#fDataTable-Nomor").removeClass("d-none");
	  }else {
	    $("#nomor-table").removeClass("w-75");
	    $("#nomor-table").addClass("w-100");
	    $("#fDataTable-Nomor").addClass("d-none");      
	  }
	});

	$("#bdelete").click(function(){
		if($("#tab-nomor").hasClass('active')){
			_delnomor();
		} 
	});    

	var _delnomor = () => {
		alert('hapus nomor');
	}

})