$(function(){
	$("#btn-tab-utility").click(function(){
	    $(".tab-wrap").removeClass("noresultfound-x");                                   
	});	
})