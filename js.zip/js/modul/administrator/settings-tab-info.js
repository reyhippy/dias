$(function() {

	$('#ibulan').select2({
	     "minimumResultsForSearch": "Infinity",                 
	     "theme":"bootstrap4"
	});

	$('#itahun').select2({
	   "allowClear": false,
	   "theme":"bootstrap4",
	   "allowAddLink": true,
	   "addLink":"form_periode",      
	   "linkTitle":"Periode",                                
	   "ajax": {
	      "url": base_url+"Select_Master/view_tahun_periode",
	      "type": "post",
	      "dataType": "json",                                       
	      "delay": 800,
	      "data": function(params) {
	        return {
	          search: params.term
	        }
	      },
	      "processResults": function (data, page) {
	      return {
	        results: data
	      };
	    },
	  }
	});	

	$("#btn-tab-menu").click(function(){
	    $(".tab-wrap").removeClass("noresultfound-x");                                   
		$("#badd").addClass("disabled");
		$("#bedit").addClass("disabled");	
		$("#bdelete").addClass("disabled");
		$("#bsave").removeClass("disabled");
	    setTimeout(function () {
	      $('#inama').focus();        
	    },300);	
	});

	_getData();

	function _getData(){
	    $.ajax({ 
	      "url"    : base_url+"Settings_Info/getdata",       
	      "type"   : "POST", 
	      "dataType" : "json", 
	      "cache"  : false,
	      "beforeSend" : function(){
	      },        
	      "error"  : function(xhr,status,error){
	        parent.window.toastr.error("Perbaiki kesalahan ini : "+xhr.responseText);
	        console.error(xhr.responseText);
	        return;
	      },
	      "success" : function(result) {
	          const _tahun = $("<option selected='selected'></option>").val(result.data[0]['idtahun']).text(result.data[0]['tahun']);	      	
	
	          $('#iid').val(result.data[0]['id']);            
	          $('#inama').val(result.data[0]['nama']);
	          $('#ialamat1').val(result.data[0]['alamat1']);
	          $('#ialamat2').val(result.data[0]['alamat2']);	
	          $('#ikota').val(result.data[0]['kota']);	
	          $('#ipropinsi').val(result.data[0]['propinsi']);
	          $('#ikodepos').val(result.data[0]['kodepos']);	          		                              
	          $('#inegara').val(result.data[0]['negara']);
	          $('#itelp1').val(result.data[0]['telp1']);	          
	          $('#itelp2').val(result.data[0]['telp2']);
	          $('#ifaks').val(result.data[0]['faks']);	          	          	          	          
	          $('#iemail').val(result.data[0]['email']);	          
	          $('#ibulan').val(result.data[0]['bulan']).trigger('change');
	          $('#itahun').append(_tahun).trigger('change');	          
	          /**/
	          return;
	    } 
	  })
	}

})